Coq Version:    8.7.0

Total Lines: around 15000 lines of definitions and proofs

Compile: 
    run "make" to compile the files.
    you can run script 'gen_makefile' to generate a new makefile, or use the
    makefile contained in this project directly.

File Structures:
├── _CoqProject
├── gen_makefile
├── makefile
├── ReadMe.txt
├── lang                            : Sec. 3 in the paper
│   ├── definitions
│   │   └── TidSpec.v
│   ├── Lang.v                      : definitions of the language and operational semantics
│   └── lemmas
│       ├── Dec.v                   : decidability of the annotated command
│       ├── Label.v                 : lemmas about the Label
│       └── OpSemantics.v           : lemmas about the operational semantics
├── typechecking                    : Sec. 4 in the paper
│       ├── lemmas
│       │   └── Env.v                   : lemmas about the type environment
│       └── Typeinfer.v                 : the translation rules
├── soundness                       : Sec. 7 and Sec. 8 in the paper
│   ├── LeakFree.v                  : Sec. 7.2 in the paper: definition of leak-freedom
│   ├── lemmas
│   │   └── Sound_lemmas.v          : some lemmas required by Sound.v
│   ├── simulation
│   │   ├── Compositionality.v      : the proof of the compositionality of the simulation
│   │   ├── Simulation.v            : definitions of simulation between two process configurations 
│   │   │                             and simulation between two program configurations
│   │   └── welltype_tsim           : proofs of the soundness of the individual rules are put in this folder
│   │       ├── definitions
│   │       │   └── ParaSeqStep.v   : definition of an auxiliary step of the process
│   │       ├── lemmas
│   │       │   ├── Inv.v           : lemmas about the invariant
│   │       │   ├── Sim_lemmas.v    : lemmas required by proofs of the soundness of some rules
│   │       │   ├── StateEquiv.v    : lemmas about the state equivalence
│   │       │   └── Term.v          : lemmas about the termination
│   │       ├── TSim_assign.v       
│   │       ├── TSim_get.v
│   │       ├── TSim_hrecv.v
│   │       ├── TSim_hsend.v
│   │       ├── TSim_if.v
│   │       ├── TSim_lrecv.v
│   │       ├── TSim_lsend.v
│   │       ├── TSim_out.v
│   │       ├── TSim_put.v
│   │       ├── TSim_seq.v
│   │       ├── TSim_skip.v
│   │       └── TSim_while.v
│   └── Sound.v                     : Sec. 8 in the paper: proof of the final theorem, soundness. 
│                                     The proof sketch in the paper is shown in this file
├── lemmas
│   ├── Base.v                      : the second mathematical induction
│   └── MListSet.v                  : some lemmas about the ListSet
└── lib                             : files in this folder are written by others and are depended by our proof
    ├── CpdtTactics.v               : a tactic library released with the book "Certified Programming with Dependent Types"
    ├── extac.v                     : required by MapLib.v
    ├── IntBool.v                   : required by MapLib.v
    └── MapLib.v                    : definition of a map and related lemmas





